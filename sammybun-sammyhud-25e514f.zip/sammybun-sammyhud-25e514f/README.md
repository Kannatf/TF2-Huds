# sammyhud
 
**Edited version of axhud.**
[Screenshots](https://imgur.com/a/WPL7OB2)

# credits
**Alex_f the original creator of [axhud](https://huds.tf/forum/showthread.php?tid=925)**

# customization
**Customization options are in the customization folder in the hud directory**
